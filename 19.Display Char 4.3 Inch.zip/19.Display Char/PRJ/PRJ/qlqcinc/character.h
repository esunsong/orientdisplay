#include "nuc970.h"
#include "gpio.h"
#define ScreenWidth		480
#define ScreenHeight	272
#define Transparent	  101

int8_t add_font(char * name,void * ptr,uint16_t width,uint16_t height,uint8_t flag,uint8_t Offset);
int8_t set_font(char * name,uint16_t width,uint8_t flag);

void font_init(uint8_t * BufPtr);
void LCD_ShowChar(uint16_t x,uint16_t y,char chr,uint16_t color,uint16_t background);
void LCD_ShowCharString(uint16_t x,uint16_t y,char *chr,uint16_t color,uint16_t background);
	


