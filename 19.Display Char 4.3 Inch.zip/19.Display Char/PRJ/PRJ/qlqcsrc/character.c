#include "character.h"
#include "string.h"
#include "sys.h"
#include "ascii.h"
#include "gpio.h"
uint16_t *FrameBufPtr;

void font_init(uint8_t * BufPtr)
{
   FrameBufPtr=(uint16_t *)BufPtr;
}
/*
LCD_ShowChar(uint16_t x,uint16_t y,char chr,uint16_t color,uint16_t background)
Display an english character
para:
  x��						x location
	y��						y location
	chr��					display character
	color��				color
	background��	background color
*/
void LCD_ShowChar(uint16_t x,uint16_t y,char chr,uint16_t color,uint16_t background)
{      			    
	u8 temp,t,t1;
	uint16_t x0=x;
	chr=chr-' ';//   offset value				   
    for(t=0;t<16;t++)
    {
		 temp=ASCII_1608[chr][t];
			                         
        for(t1=0;t1<8;t1++)
			{
				if(temp&0x80)
				{	
				  if(color!=Transparent)
					FrameBufPtr[ScreenWidth*y+x]=color;
				}
				else 
				{	
					if(background!=Transparent)
					FrameBufPtr[ScreenWidth*y+x]=background;
				}
				temp<<=1;
				x++;
			}  	 
			x=x0;
			y++;
    }          
}

void LCD_ShowCharString(uint16_t x,uint16_t y,char *chr,uint16_t color,uint16_t background)
{      			    
	while(*chr)
	{
		LCD_ShowChar( x,y,* chr,color,background);
		x+=8;
		chr ++;
	}
}

