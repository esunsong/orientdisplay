/*-----------------------NUC972 development board Examples--------------------

Example description:

This example realizes the use of LCD screen to display English strings

hardware connection

PA0 LCD LD0
PA1 LCD LD1
PA2 LCD LD2
PA3 LCD LD3
PA4 LCD LD4
PA5 LCD LD5
PA6 LCD LD6
PA7 LCD LD7
PA8 LCD LD8
PA9 LCD LD9
PA10 LCD LD10
PA11 LCD LD11
PA12 LCD LD12
PA13 LCD LD13
PA14 LCD LD14
PA15 LCD LD15

PG2 LCD screen LCS
PG3 LCD BLEN

PG6 LCD LCLK
PG7 LCD LH
PG8 LCD LV
PG9 LCD LDE

Compilation environment: Keil 5.24a

-------*/
#include <stdio.h>
#include <string.h>
#include "gpio.h"
#include "nuc970.h"
#include "sys.h"
#include "lcd.h"
#include "character.h"
//#include "ascii.h"
__align(32) uint32_t u32CursorBuf[512];

int32_t main(void)
{
	uint8_t *u8FrameBufPtr;
	int i;
/************************** System initialization starts **********************/
    outpw(REG_AIC_MDCR, 0xFFFFFFFE);
    outpw(REG_AIC_MDCRH, 0x3FFFFFFF);
    sysDisableCache();
    sysFlushCache(I_D_CACHE);
    sysEnableCache(CACHE_WRITE_BACK);
		outpw(REG_CLK_HCLKEN, 0x0527);
	  outpw(REG_CLK_PCLKEN0, 0);
	  outpw(REG_CLK_PCLKEN1, 0);
/************************** System initialization end *********************/
	  //System debugging serial port initialization Serial port 0 115200
    sysInitializeUART();
    sysprintf("\r\n-----English character display experiment-------\r\n");
	  sysprintf("---------Orient Display--------\r\n");
	  sysprintf("-------------------------------\r\n");	

    sysprintf("Please connect a 4.3 inch LCD screen\r\n");
	
	
	  // Turn on LCM backlight
	  GPIO_OpenBit(GPIOG,BIT10, DIR_OUTPUT, PULL_UP);
	  GPIO_Set(GPIOG,BIT10);
	
	  // Configuration pins are multiplexed to LCM
		//GPG6 (CLK), GPG7 (HSYNC)
		outpw(REG_SYS_GPG_MFPL, (inpw(REG_SYS_GPG_MFPL)& ~0xFF000000) | 0x22000000);
		//GPG8 (VSYNC), GPG9 (DEN)
		outpw(REG_SYS_GPG_MFPH, (inpw(REG_SYS_GPG_MFPH)& ~0xFF) | 0x22);
		//GPA0 ~ GPA7 (DATA0~7)
		outpw(REG_SYS_GPA_MFPL, 0x22222222);
		//GPA8 ~ GPA15 (DATA8~15)	
		outpw(REG_SYS_GPA_MFPH, 0x22222222);

			
	  //enable LCD clock
	  outpw(REG_CLK_DIVCTL1, (inpw(REG_CLK_DIVCTL1) & ~0xff1f) | 0x1518);		
	 //LCD Init
	  vpostLCMInit(1);
	 //Set the zoom ratio to 1:1
	  vpostVAScalingCtrl(1, 0, 1, 0, VA_SCALE_INTERPOLATION);
	//set pixel format RGB565
    vpostSetVASrc(VA_SRC_RGB565);
	// Get the display memory address pointer
	u8FrameBufPtr = vpostGetFrameBuffer();
    if(u8FrameBufPtr == NULL)
	{
		sysprintf("Failed to get memory address pointer!!\n");
		return 0;
	}
		vpostVAStartTrigger();
	 //Brush full screen to red
	 for(i=0;i<320*240;i++)
	{
	   ((unsigned short*)u8FrameBufPtr)[i]=0xf800;
	}
	 //The above is the initialization of the LCD screen, The following is the character display
	 //Initialize character, Pass the display memory address pointer to the character function
	 font_init(u8FrameBufPtr);
  
	 sysprintf("Orient Display, Orient Display, Orient Display \r\n");

	//Display characters White characters and black background
	 LCD_ShowCharString(50,50, "Orient Display, Orient Display, Orient Display",0xffff,0);
	//Display characters Red lettering and blue background
	 LCD_ShowCharString(50,100,"Orient Display, Orient Display, Orient Display",0xf800,0x1f);
	//Display characters Black characters with transparent bottom
	 LCD_ShowCharString(50,150,"Orient Display, Orient Display, Orient Display",0,Transparent);
	//Display characters Transparent characters on white background
	 LCD_ShowCharString(50,200,"Orient Display, Orient Display, Orient Display",Transparent,0xffff);

   while(1);
}
