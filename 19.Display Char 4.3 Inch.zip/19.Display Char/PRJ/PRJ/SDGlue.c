/******************************************************************************
 * @file     SDGlue.c
 * @version  V1.00
 * $Revision: 2 $
 * $Date: 15/06/12 10:03a $
 * @brief    SD glue functions for FATFS
 *
 * @note
 * Copyright (C) 2013 Nuvoton Technology Corp. All rights reserved.
*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "nuc970.h"
#include "sys.h"
#include "sdh.h"
#include "ff.h"
#include "diskio.h"

extern int sd0_ok;
extern int sd1_ok;

FATFS  _FatfsVolSd0;
FATFS  _FatfsVolSd1;

static TCHAR  _Path[3] = { '0', ':', 0 };

void SD_Open_Disk(unsigned int cardSel)
{
    switch(cardSel & 0xff)
    {
        case SD_PORT0:
            SD_Open(cardSel);
            if (SD_Probe(cardSel & 0x00ff) != TRUE) {
                sysprintf("SD0 initial fail!!\n");
                return;
            }
            f_mount(&_FatfsVolSd0, _Path, 1);
            break;

        case SD_PORT1:
            SD_Open(cardSel);
            if (SD_Probe(cardSel & 0x00ff) != TRUE) {
                sysprintf("SD1 initial fail!!\n");
                return;
            }
            _Path[0] = 	1 + '0';	
            f_mount(&_FatfsVolSd1, _Path, 1);
            break;
    }
}

void SD_Close_Disk(unsigned int cardSel)
{
    if (cardSel == SD_PORT0) {
        sd0_ok = 0;
        memset(&SD0, 0, sizeof(SD_INFO_T));
        f_mount(NULL, _Path, 1);
        memset(&_FatfsVolSd0, 0, sizeof(FATFS));
    } else if(cardSel == SD_PORT1) {
        sd1_ok = 0;
        memset(&SD1, 0, sizeof(SD_INFO_T));
        _Path[0] = 	1 + '0';	
        f_mount(NULL, _Path, 1);
        memset(&_FatfsVolSd1, 0, sizeof(FATFS));
    }
}
/*
��������void SDH_IRQHandler(void)
���ܣ�SDH�жϷ������
������					��
����ֵ��				��
*/
void SDH_IRQHandler(void)
{
    unsigned int volatile isr;

    // FMI data abort interrupt
    if (inpw(REG_SDH_GINTSTS) & SDH_GINTSTS_DTAIF_Msk) {
        /* ResetAllEngine() */
        outpw(REG_SDH_GCTL, inpw(REG_SDH_GCTL) | SDH_GCTL_GCTLRST_Msk);
        outpw(REG_SDH_GINTSTS, SDH_GINTSTS_DTAIF_Msk);
    }

	//----- SD interrupt status
	isr = inpw(REG_SDH_INTSTS);
	if (isr & SDH_INTSTS_BLKDIF_Msk)		// block down
	{
		_sd_SDDataReady = TRUE;
		outpw(REG_SDH_INTSTS, SDH_INTSTS_BLKDIF_Msk);
	}

    if (isr & SDH_INTSTS_CDIF0_Msk) { // port 0 card detect
        //----- SD interrupt status
        // it is work to delay 50 times for SD_CLK = 200KHz
        {
    	    volatile int i;         // delay 30 fail, 50 OK
    	    for (i=0; i<0x500;i++)
					;    // delay to make sure got updated value from REG_SDISR.
            isr = inpw(REG_SDH_INTSTS);
        }

#ifdef _USE_DAT3_DETECT_
        if (!(isr & SDH_INTSTS_CDSTS0_Msk)) {
            SD0.IsCardInsert = FALSE;
            sysprintf("\r\nCard Remove!\r\n");
            SD_Close_Disk(0);
        } else {
            SD_Open_Disk(SD_PORT0 | CardDetect_From_DAT3);
        }
#else
        if (isr & SDH_INTSTS_CDSTS0_Msk) {
            SD0.IsCardInsert = FALSE;   // SDISR_CD_Card = 1 means card remove for GPIO mode
            sysprintf("\r\nCard Remove!\r\n");
            SD_Close_Disk(0);
        } else {
            SD_Open_Disk(SD_PORT0 | CardDetect_From_GPIO);
        }
#endif

        outpw(REG_SDH_INTSTS, SDH_INTSTS_CDIF0_Msk);
    }

    if (isr & SDH_INTSTS_CDIF1_Msk) { // port 1 card detect
        //----- SD interrupt status
        // it is work to delay 50 times for SD_CLK = 200KHz
        {
    	    volatile int i;         // delay 30 fail, 50 OK
    	    for (i=0; i<0x500;i++)
					;    // delay to make sure got updated value from REG_SDISR.
            isr = inpw(REG_SDH_INTSTS);
        }

#ifdef _USE_DAT3_DETECT_
        if (!(isr & SDH_INTSTS_CDSTS1_Msk)) {
            SD0.IsCardInsert = FALSE;
            sysprintf("\r\nCard Remove!\r\n");
            SD_Close_Disk(1);
        } else {
            SD_Open_Disk(SD_PORT1 | CardDetect_From_DAT3);
        }
#else
        if (isr & SDH_INTSTS_CDSTS1_Msk) {
            SD0.IsCardInsert = FALSE;   // SDISR_CD_Card = 1 means card remove for GPIO mode
            sysprintf("\r\nCard Remove!\r\n");
            SD_Close_Disk(1);
        } else {
            SD_Open_Disk(SD_PORT1 | CardDetect_From_GPIO);
        }
#endif

        outpw(REG_SDH_INTSTS, SDH_INTSTS_CDIF1_Msk);
    }

    // CRC error interrupt
    if (isr & SDH_INTSTS_CRCIF_Msk) {
        if (!(isr & SDH_INTSTS_CRC16_Msk)) {
            //sysprintf("***** ISR sdioIntHandler(): CRC_16 error !\r\n");
            // handle CRC error
        } else if (!(isr & SDH_INTSTS_CRC7_Msk)) {
            extern unsigned int _sd_uR3_CMD;
            if (! _sd_uR3_CMD) {
                //sysprintf("***** ISR sdioIntHandler(): CRC_7 error !\r\n");
                // handle CRC error
            }
        }
        outpw(REG_SDH_INTSTS, SDH_INTSTS_CRCIF_Msk);      // clear interrupt flag
    }
}
/*
��������unsigned long get_fattime (void)
���ܣ�RTCʱ�ӻص�����
������					��
����ֵ��				RTCʱ��
*/
unsigned long get_fattime (void)
{
    unsigned long tmr;
    tmr=0x00000;
    return tmr;
}
/*
��������void put_rc (FRESULT rc)
���ܣ������ӡ
������
	rc��			�������
����ֵ��				��
*/
void put_rc (FRESULT rc)
{
    const TCHAR *p =
        _T("OK\0DISK_ERR\0INT_ERR\0NOT_READY\0NO_FILE\0NO_PATH\0INVALID_NAME\0")
        _T("DENIED\0EXIST\0INVALID_OBJECT\0WRITE_PROTECTED\0INVALID_DRIVE\0")
        _T("NOT_ENABLED\0NO_FILE_SYSTEM\0MKFS_ABORTED\0TIMEOUT\0LOCKED\0")
        _T("NOT_ENOUGH_CORE\0TOO_MANY_OPEN_FILES\0");
    uint32_t i;
    for (i = 0; (i != (UINT)rc) && *p; i++) {
        while(*p++) ;
    }
    sysprintf(_T("rc=%d FR_%s\r\n"), (UINT)rc, p);
}

